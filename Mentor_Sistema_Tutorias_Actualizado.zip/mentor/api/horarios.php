<?php
require_once __DIR__ . '/_common.php';
exigirRol('admin');
try {
    if ($_SERVER['REQUEST_METHOD']==='GET') responder($pdo->query('SELECT id,dia_semana,hora_inicio,hora_fin FROM horarios WHERE activo=1 ORDER BY id DESC')->fetchAll(PDO::FETCH_ASSOC));
    if ($_SERVER['REQUEST_METHOD']!=='POST') responder(['exito'=>false,'mensaje'=>'Método no permitido.'],405);
    $accion=$_POST['accion'] ?? 'crear';$id=numero($_POST['id'] ?? 0);
    if ($accion==='eliminar') {
        $q=$pdo->prepare('UPDATE horarios SET activo=0 WHERE id=?');$q->execute([$id]);responder(['exito'=>true]);
    }
    if (!in_array($accion,['crear','editar'],true)) responder(['exito'=>false,'mensaje'=>'Acción inválida.']);
    $dia=$_POST['dia_semana'] ?? '';$inicio=$_POST['hora_inicio'] ?? '';$fin=$_POST['hora_fin'] ?? '';
    if (!in_array($dia,['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'],true) || !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/',$inicio) || !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/',$fin) || $fin<=$inicio) responder(['exito'=>false,'mensaje'=>'Día u horas inválidas. La hora final debe ser posterior a la inicial.']);
    if ($accion==='crear') {
        $q=$pdo->prepare('INSERT INTO horarios(dia_semana,hora_inicio,hora_fin,activo) VALUES (?,?,?,1)');$q->execute([$dia,$inicio,$fin]);
    } else {
        // No alteramos un bloque usado por tutorías en curso; preserva su día y horas.
        $q=$pdo->prepare("SELECT COUNT(*) FROM solicitudes WHERE id_horario=? AND estado IN ('pendiente','confirmada')");$q->execute([$id]);
        if ($q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'Este horario tiene tutorías activas. Cancélalas o resuélvelas antes de editarlo.']);
        $q=$pdo->prepare('UPDATE horarios SET dia_semana=?,hora_inicio=?,hora_fin=? WHERE id=?');$q->execute([$dia,$inicio,$fin,$id]);
    }
    responder(['exito'=>true]);
} catch (PDOException $e) { responder(['exito'=>false,'mensaje'=>'No se pudo guardar el horario.']); }
