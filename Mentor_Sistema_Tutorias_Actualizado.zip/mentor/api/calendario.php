<?php
require_once __DIR__ . '/_common.php';
$idUsuario=exigirRol('alumno','tutor','admin');
$rol=$_SESSION['rol'];
$desde=$_GET['desde'] ?? ''; $hasta=$_GET['hasta'] ?? '';
if (!validarFecha($desde) || !validarFecha($hasta) || $desde>$hasta || (new DateTimeImmutable($desde))->diff(new DateTimeImmutable($hasta))->days>93) responder(['exito'=>false,'mensaje'=>'Intervalo de fechas no válido.'],400);
try {
    $sql='SELECT s.id,s.fecha_especifica,s.estado,s.id_alumno,s.id_tutor,m.nombre AS materia,h.hora_inicio,h.hora_fin,a.nombre AS alumno,t.nombre AS tutor FROM solicitudes s JOIN materias m ON m.id=s.id_materia JOIN horarios h ON h.id=s.id_horario JOIN usuarios a ON a.id=s.id_alumno LEFT JOIN usuarios t ON t.id=s.id_tutor WHERE s.fecha_especifica BETWEEN :desde AND :hasta';
    $param=[':desde'=>$desde,':hasta'=>$hasta];
    if ($rol==='alumno') { $sql.=" AND s.id_alumno=:id AND s.estado IN ('pendiente','confirmada')";$param[':id']=$idUsuario; }
    elseif ($rol==='tutor') { $sql.=" AND s.id_tutor=:id AND s.estado='confirmada'";$param[':id']=$idUsuario; }
    $sql.=' ORDER BY s.fecha_especifica,h.hora_inicio,s.id';
    $q=$pdo->prepare($sql);$q->execute($param);
    responder(['exito'=>true,'rol'=>$rol,'usuario'=>$_SESSION['nombre'],'eventos'=>$q->fetchAll(PDO::FETCH_ASSOC)]);
} catch (PDOException $e) { responder(['exito'=>false,'mensaje'=>'No fue posible cargar el calendario.']); }
