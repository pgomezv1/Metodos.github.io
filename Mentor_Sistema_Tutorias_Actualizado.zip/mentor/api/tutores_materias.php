<?php
require_once __DIR__ . '/_common.php';
exigirRol('admin');
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $tutores = $pdo->query("SELECT id, nombre, carne FROM usuarios WHERE rol='tutor' AND activo=1 ORDER BY nombre")->fetchAll(PDO::FETCH_ASSOC);
        $materias = $pdo->query('SELECT m.id, m.nombre, c.nombre AS carrera FROM materias m JOIN carreras c ON c.id=m.id_carrera WHERE m.activo=1 AND c.activo=1 ORDER BY c.nombre, m.nombre')->fetchAll(PDO::FETCH_ASSOC);
        $relaciones = $pdo->query('SELECT tm.id_tutor, tm.id_materia FROM tutor_materia tm JOIN usuarios u ON u.id=tm.id_tutor AND u.activo=1 AND u.rol="tutor"')->fetchAll(PDO::FETCH_ASSOC);
        responder(['tutores'=>$tutores,'materias'=>$materias,'relaciones'=>$relaciones]);
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || ($_POST['accion'] ?? '') !== 'guardar') responder(['exito'=>false,'mensaje'=>'Acción no permitida.'],405);
    $idTutor=numero($_POST['id_tutor'] ?? 0);
    $materias=$_POST['materias'] ?? [];
    if (!is_array($materias)) responder(['exito'=>false,'mensaje'=>'Selección de materias inválida.']);
    $ids=array_values(array_unique(array_map('numero',$materias)));
    if (in_array(0,$ids,true)) responder(['exito'=>false,'mensaje'=>'Existe una materia inválida.']);
    $pdo->beginTransaction();
    $q=$pdo->prepare("SELECT id FROM usuarios WHERE id=? AND rol='tutor' AND activo=1 FOR UPDATE");$q->execute([$idTutor]);
    if (!$q->fetchColumn()) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'Tutor no disponible.']); }
    if ($ids) {
        $slots=implode(',',array_fill(0,count($ids),'?'));
        $q=$pdo->prepare("SELECT COUNT(*) FROM materias m JOIN carreras c ON c.id=m.id_carrera WHERE m.id IN ($slots) AND m.activo=1 AND c.activo=1");
        $q->execute($ids);
        if ((int)$q->fetchColumn() !== count($ids)) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'Una materia ya no está disponible.']); }
    }
    $q=$pdo->prepare('DELETE FROM tutor_materia WHERE id_tutor=?');$q->execute([$idTutor]);
    $q=$pdo->prepare('INSERT INTO tutor_materia(id_tutor,id_materia) VALUES (?,?)');
    foreach ($ids as $idMateria) $q->execute([$idTutor,$idMateria]);
    $pdo->commit();
    responder(['exito'=>true,'mensaje'=>'Materias del tutor actualizadas.']);
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    responder(['exito'=>false,'mensaje'=>'No fue posible actualizar las materias asignadas.']);
}
