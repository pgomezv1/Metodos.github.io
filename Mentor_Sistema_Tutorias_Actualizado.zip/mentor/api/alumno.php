<?php
require_once __DIR__ . '/_common.php';
$idAlumno=exigirRol('alumno');
if ($_SERVER['REQUEST_METHOD']!=='POST') responder(['exito'=>false,'mensaje'=>'Método no permitido.'],405);
$accion=$_POST['accion'] ?? '';
try {
    if ($accion==='obtener_catalogos') {
        $q=$pdo->prepare("SELECT u.nombre,u.carne,u.id_carrera,c.nombre AS carrera FROM usuarios u LEFT JOIN carreras c ON c.id=u.id_carrera WHERE u.id=? AND u.activo=1");
        $q->execute([$idAlumno]);$alumno=$q->fetch(PDO::FETCH_ASSOC);
        if (!$alumno) responder(['exito'=>false,'mensaje'=>'Cuenta no disponible.'],403);
        $q=$pdo->prepare('SELECT m.id,m.nombre FROM materias m JOIN carreras c ON c.id=m.id_carrera AND c.activo=1 WHERE m.activo=1 AND m.id_carrera=? ORDER BY m.nombre');
        $q->execute([$alumno['id_carrera']]);
        $materias=$q->fetchAll(PDO::FETCH_ASSOC);
        $horarios=$pdo->query('SELECT id,dia_semana,hora_inicio,hora_fin FROM horarios WHERE activo=1 ORDER BY hora_inicio')->fetchAll(PDO::FETCH_ASSOC);
        responder(['materias'=>$materias,'horarios'=>$horarios,'alumno'=>$alumno]);
    }
    if ($accion==='obtener_mis_solicitudes') {
        $q=$pdo->prepare('SELECT s.id,s.id_materia,s.fecha_especifica,s.estado,m.nombre AS materia,h.dia_semana,h.hora_inicio,h.hora_fin,t.nombre AS tutor FROM solicitudes s JOIN materias m ON m.id=s.id_materia JOIN horarios h ON h.id=s.id_horario LEFT JOIN usuarios t ON t.id=s.id_tutor WHERE s.id_alumno=? ORDER BY s.fecha_especifica DESC,h.hora_inicio DESC');
        $q->execute([$idAlumno]);responder($q->fetchAll(PDO::FETCH_ASSOC));
    }
    if ($accion==='crear_solicitud') {
        $materia=numero($_POST['id_materia'] ?? 0);$horario=numero($_POST['id_horario'] ?? 0);$fecha=$_POST['fecha_especifica'] ?? '';
        if (!$materia || !$horario || !validarFecha($fecha) || $fecha < date('Y-m-d')) responder(['exito'=>false,'mensaje'=>'Revisa materia, horario y fecha. No se permiten fechas pasadas.']);
        $pdo->beginTransaction();
        // Bloquear el usuario serializa reservas simultáneas del mismo alumno.
        $q=$pdo->prepare("SELECT id_carrera FROM usuarios WHERE id=? AND rol='alumno' AND activo=1 FOR UPDATE");$q->execute([$idAlumno]);$carrera=$q->fetchColumn();
        $q=$pdo->prepare('SELECT m.id FROM materias m JOIN carreras c ON c.id=m.id_carrera AND c.activo=1 WHERE m.id=? AND m.id_carrera=? AND m.activo=1');
        $q->execute([$materia,$carrera]);
        if (!$q->fetchColumn()) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'La materia no corresponde a tu carrera.']); }
        if (!horarioValido($pdo,$horario,$fecha)) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'El bloque horario no corresponde al día elegido.']); }
        $q=$pdo->prepare('SELECT COUNT(*) FROM solicitudes s JOIN horarios ocupado ON ocupado.id=s.id_horario JOIN horarios nuevo ON nuevo.id=? WHERE s.id_alumno=? AND s.fecha_especifica=? AND s.estado IN ("pendiente","confirmada") AND ocupado.hora_inicio<nuevo.hora_fin AND ocupado.hora_fin>nuevo.hora_inicio');
        $q->execute([$horario,$idAlumno,$fecha]);
        if ((int)$q->fetchColumn()>0) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'Ya tienes una tutoría pendiente o confirmada que se cruza con ese horario.']); }
        $q=$pdo->prepare('INSERT INTO solicitudes(id_alumno,id_materia,id_horario,fecha_especifica,estado) VALUES (?,?,?,? ,"pendiente")');
        $q->execute([$idAlumno,$materia,$horario,$fecha]);
        $pdo->commit();responder(['exito'=>true,'mensaje'=>'Solicitud registrada.']);
    }
    if ($accion==='cancelar_solicitud') {
        $id=numero($_POST['id'] ?? 0);
        $q=$pdo->prepare("UPDATE solicitudes SET estado='cancelada' WHERE id=? AND id_alumno=? AND estado IN ('pendiente','confirmada')");
        $q->execute([$id,$idAlumno]);
        responder(['exito'=>$q->rowCount()>0,'mensaje'=>$q->rowCount()?'Tutoría cancelada.':'No se puede cancelar esta solicitud.']);
    }
    responder(['exito'=>false,'mensaje'=>'Acción inválida.']);
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    responder(['exito'=>false,'mensaje'=>'Error al procesar la tutoría.']);
}
