<?php
require_once __DIR__ . '/_common.php';
exigirRol('admin');
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $todos = isset($_GET['todos']) && $_GET['todos'] === '1';
        $sql = 'SELECT c.id, c.nombre, c.descripcion, c.activo, (SELECT COUNT(*) FROM usuarios u WHERE u.id_carrera=c.id AND u.rol="alumno" AND u.activo=1) AS alumnos, (SELECT COUNT(*) FROM materias m WHERE m.id_carrera=c.id AND m.activo=1) AS materias FROM carreras c';
        if (!$todos) $sql .= ' WHERE c.activo=1';
        responder($pdo->query($sql.' ORDER BY c.nombre')->fetchAll(PDO::FETCH_ASSOC));
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(['exito'=>false, 'mensaje'=>'Método no permitido.'], 405);
    $accion = $_POST['accion'] ?? 'crear';
    $id = numero($_POST['id'] ?? 0);
    if (in_array($accion, ['crear','editar'], true)) {
        $nombre = trim($_POST['nombre'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        if (strlen($nombre) < 3 || strlen($nombre) > 120) responder(['exito'=>false,'mensaje'=>'El nombre debe tener entre 3 y 120 caracteres.']);
        if ($accion === 'crear') {
            $q=$pdo->prepare('INSERT INTO carreras(nombre, descripcion) VALUES (?,?)');$q->execute([$nombre,$descripcion]);
        } else {
            if (!$id) responder(['exito'=>false,'mensaje'=>'Carrera inválida.']);
            $q=$pdo->prepare('UPDATE carreras SET nombre=?, descripcion=? WHERE id=?');$q->execute([$nombre,$descripcion,$id]);
        }
        responder(['exito'=>true]);
    }
    if ($accion === 'eliminar' || $accion === 'reactivar') {
        if (!$id) responder(['exito'=>false, 'mensaje'=>'Carrera inválida.']);
        // Una carrera histórica no se borra físicamente.
        $q=$pdo->prepare('UPDATE carreras SET activo=? WHERE id=?');$q->execute([$accion === 'reactivar' ? 1 : 0,$id]);
        responder(['exito'=>true]);
    }
    responder(['exito'=>false,'mensaje'=>'Acción no válida.']);
} catch (PDOException $e) {
    responder(['exito'=>false,'mensaje'=>mensajeErrorDB($e,'Error al guardar la carrera.')]);
}
