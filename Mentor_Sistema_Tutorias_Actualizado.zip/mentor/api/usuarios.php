<?php
require_once __DIR__ . '/_common.php';
exigirRol('admin');
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $sql = "SELECT u.id, u.carne, u.nombre, u.correo, u.rol, u.id_carrera, u.activo, c.nombre AS carrera FROM usuarios u LEFT JOIN carreras c ON c.id=u.id_carrera ORDER BY u.id DESC";
        responder($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC));
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(['exito'=>false,'mensaje'=>'Método no permitido.'],405);
    $accion=$_POST['accion'] ?? 'crear';
    $id=numero($_POST['id'] ?? 0);
    if ($accion==='eliminar' || $accion==='reactivar') {
        if ($id===(int)$_SESSION['usuario_id'] && $accion==='eliminar') responder(['exito'=>false,'mensaje'=>'No puedes desactivar tu propia cuenta.']);
        if ($accion==='eliminar') {
            $q=$pdo->prepare('SELECT COUNT(*) FROM solicitudes WHERE (id_alumno=? OR id_tutor=?) AND estado IN ("pendiente","confirmada")');$q->execute([$id,$id]);
            if ($q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'Resuelve primero las tutorías activas antes de desactivar este usuario.']);
        }
        $q=$pdo->prepare('UPDATE usuarios SET activo=? WHERE id=?');$q->execute([$accion==='reactivar'?1:0,$id]);
        responder(['exito'=>true]);
    }
    if (!in_array($accion,['crear','editar'],true)) responder(['exito'=>false,'mensaje'=>'Acción no válida.']);
    $carne=trim($_POST['carne'] ?? '');$nombre=trim($_POST['nombre'] ?? '');$correo=trim($_POST['correo'] ?? '');
    $rol=$_POST['rol'] ?? ''; $idCarrera=numero($_POST['id_carrera'] ?? 0);
    $contrasena=$_POST['contrasena'] ?? '';
    if ($carne==='' || strlen($carne)>50 || strlen($nombre)<2 || strlen($nombre)>100 || !in_array($rol,['admin','alumno','tutor'],true)) responder(['exito'=>false,'mensaje'=>'Verifica carné, nombre y rol.']);
    if ($correo!=='' && !filter_var($correo,FILTER_VALIDATE_EMAIL)) responder(['exito'=>false,'mensaje'=>'El correo no es válido.']);
    if ($rol==='alumno') {
        if (!$idCarrera) responder(['exito'=>false,'mensaje'=>'Debes asignar una carrera al alumno.']);
        $q=$pdo->prepare('SELECT id FROM carreras WHERE id=? AND activo=1');$q->execute([$idCarrera]);
        if (!$q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'La carrera no está disponible.']);
    } else $idCarrera=null;
    $q=$pdo->prepare('SELECT COUNT(*) FROM usuarios WHERE id<>? AND (carne=? OR (correo IS NOT NULL AND correo=?) OR (?<>"" AND (correo=? OR carne=?)))');
    $q->execute([$accion==='editar'?$id:0,$carne,$carne,$correo,$correo,$correo]);
    if ($q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'Carné o correo ya utilizado por otro usuario.']);
    if ($accion==='crear') {
        if (strlen($contrasena)<8) responder(['exito'=>false,'mensaje'=>'La contraseña debe tener al menos 8 caracteres.']);
        $q=$pdo->prepare('INSERT INTO usuarios(carne,nombre,correo,contrasena,rol,id_carrera,activo) VALUES (?,?,?,?,?,?,1)');
        $q->execute([$carne,$nombre,$correo?:null,password_hash($contrasena,PASSWORD_DEFAULT),$rol,$idCarrera]);
    } else {
        if (!$id) responder(['exito'=>false,'mensaje'=>'Usuario inválido.']);
        if ($id===(int)$_SESSION['usuario_id'] && $rol!=='admin') responder(['exito'=>false,'mensaje'=>'No puedes quitarte el rol de administrador.']);
        $q=$pdo->prepare('SELECT rol FROM usuarios WHERE id=?');$q->execute([$id]);
        $rolAnterior=$q->fetchColumn();
        if (!$rolAnterior) responder(['exito'=>false,'mensaje'=>'El usuario no existe.']);
        if ($rolAnterior==='tutor' && $rol!=='tutor') {
            $q=$pdo->prepare('SELECT COUNT(*) FROM solicitudes WHERE id_tutor=? AND estado="confirmada"');$q->execute([$id]);
            if ($q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'Reasigna primero las tutorías confirmadas del docente.']);
        }
        if ($rolAnterior==='alumno' && $rol!=='alumno') {
            $q=$pdo->prepare('SELECT COUNT(*) FROM solicitudes WHERE id_alumno=? AND estado IN ("pendiente","confirmada")');$q->execute([$id]);
            if ($q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'Resuelve primero las solicitudes activas del alumno.']);
        }
        if ($rol==='alumno') {
            $q=$pdo->prepare('SELECT COUNT(*) FROM solicitudes s JOIN materias m ON m.id=s.id_materia WHERE s.id_alumno=? AND s.estado IN ("pendiente","confirmada") AND COALESCE(m.id_carrera,0)<>?');
            $q->execute([$id,$idCarrera]);
            if ($q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'No puedes cambiar la carrera mientras existan solicitudes activas de materias ajenas.']);
        }
        $q=$pdo->prepare('UPDATE usuarios SET carne=?,nombre=?,correo=?,rol=?,id_carrera=? WHERE id=?');
        $q->execute([$carne,$nombre,$correo?:null,$rol,$idCarrera,$id]);
        if ($contrasena!=='') {
            if (strlen($contrasena)<8) responder(['exito'=>false,'mensaje'=>'La contraseña debe tener al menos 8 caracteres.']);
            $q=$pdo->prepare('UPDATE usuarios SET contrasena=? WHERE id=?');$q->execute([password_hash($contrasena,PASSWORD_DEFAULT),$id]);
        }
        if ($rol!=='tutor') { $q=$pdo->prepare('DELETE FROM tutor_materia WHERE id_tutor=?');$q->execute([$id]); }
    }
    responder(['exito'=>true]);
} catch (PDOException $e) { responder(['exito'=>false,'mensaje'=>mensajeErrorDB($e,'No se pudo guardar el usuario.')]); }
