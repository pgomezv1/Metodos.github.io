<?php
// Funciones comunes de los endpoints de Mentor.
require_once __DIR__ . '/../conexion.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off','httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

function responder($datos, $codigo = 200) {
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function exigirRol(...$roles) {
    global $pdo;
    if (empty($_SESSION['usuario_id']) || !in_array($_SESSION['rol'] ?? '', $roles, true)) {
        responder(['exito'=>false, 'mensaje'=>'Sesión vencida o acceso no autorizado.'], 403);
    }
    $q=$pdo->prepare('SELECT rol,activo FROM usuarios WHERE id=?');
    $q->execute([(int)$_SESSION['usuario_id']]);
    $usuario=$q->fetch(PDO::FETCH_ASSOC);
    if (!$usuario || !$usuario['activo'] || $usuario['rol']!==$_SESSION['rol']) {
        $_SESSION=[];
        responder(['exito'=>false, 'mensaje'=>'La sesión ya no está vigente.'], 403);
    }
    return (int) $_SESSION['usuario_id'];
}
function numero($valor) { return filter_var($valor, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]) ?: 0; }
function validarFecha($fecha) {
    if (!is_string($fecha) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha)) return false;
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $fecha);
    return $d && $d->format('Y-m-d') === $fecha;
}
function mensajeErrorDB($e, $generico = 'No se pudo procesar la operación.') {
    if ($e instanceof PDOException && $e->getCode() === '23000') return 'Registro duplicado o relacionado con otros registros.';
    return $generico;
}
function diaDeFecha($fecha) {
    $dias = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
    return $dias[(int)(new DateTimeImmutable($fecha))->format('w')];
}
function horarioValido($pdo, $idHorario, $fecha) {
    $q = $pdo->prepare('SELECT dia_semana, hora_inicio, hora_fin FROM horarios WHERE id=? AND activo=1');
    $q->execute([$idHorario]);
    $h = $q->fetch(PDO::FETCH_ASSOC);
    return $h && $h['dia_semana'] === diaDeFecha($fecha) && $h['hora_fin'] > $h['hora_inicio'];
}
