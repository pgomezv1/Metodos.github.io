<?php
require_once __DIR__ . '/_common.php';
exigirRol('admin');
try {
    $q=$pdo->query("SELECT COUNT(*) FROM solicitudes WHERE estado='pendiente'");
    responder(['exito'=>true,'pendientes'=>(int)$q->fetchColumn()]);
} catch (PDOException $e) {
    responder(['exito'=>false,'pendientes'=>0,'mensaje'=>'Error al cargar los indicadores.']);
}
