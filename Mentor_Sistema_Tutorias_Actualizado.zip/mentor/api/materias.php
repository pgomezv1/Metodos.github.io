<?php
require_once __DIR__ . '/_common.php';
exigirRol('admin');
try {
    if ($_SERVER['REQUEST_METHOD']==='GET') {
        responder($pdo->query('SELECT m.id,m.nombre,m.descripcion,m.id_carrera,c.nombre AS carrera,m.activo FROM materias m LEFT JOIN carreras c ON c.id=m.id_carrera WHERE m.activo=1 ORDER BY m.id DESC')->fetchAll(PDO::FETCH_ASSOC));
    }
    if ($_SERVER['REQUEST_METHOD']!=='POST') responder(['exito'=>false,'mensaje'=>'Método no permitido.'],405);
    $accion=$_POST['accion'] ?? 'crear';$id=numero($_POST['id'] ?? 0);
    if ($accion==='eliminar') {
        $q=$pdo->prepare('SELECT COUNT(*) FROM solicitudes WHERE id_materia=? AND estado IN ("pendiente","confirmada")');$q->execute([$id]);
        if ($q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'Resuelve las solicitudes activas antes de desactivar esta materia.']);
        $q=$pdo->prepare('UPDATE materias SET activo=0 WHERE id=?');$q->execute([$id]);responder(['exito'=>true]);
    }
    if (!in_array($accion,['crear','editar'],true)) responder(['exito'=>false,'mensaje'=>'Acción inválida.']);
    $nombre=trim($_POST['nombre'] ?? '');$descripcion=trim($_POST['descripcion'] ?? '');$idCarrera=numero($_POST['id_carrera'] ?? 0);
    if ($nombre==='' || strlen($nombre)>100 || !$idCarrera) responder(['exito'=>false,'mensaje'=>'Nombre y carrera son obligatorios.']);
    $q=$pdo->prepare('SELECT id FROM carreras WHERE id=? AND activo=1');$q->execute([$idCarrera]);
    if (!$q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'Carrera inexistente o inactiva.']);
    // Mismo nombre en distintas carreras sí está permitido.
    $q=$pdo->prepare('SELECT id FROM materias WHERE nombre=? AND id_carrera=? AND activo=1 AND id<>? LIMIT 1');
    $q->execute([$nombre,$idCarrera,$accion==='editar'?$id:0]);
    if ($q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'Esta materia ya existe en la carrera seleccionada.']);
    if ($accion==='editar') {
        $q=$pdo->prepare('SELECT COUNT(*) FROM solicitudes s JOIN usuarios a ON a.id=s.id_alumno WHERE s.id_materia=? AND s.estado IN ("pendiente","confirmada") AND COALESCE(a.id_carrera,0)<>?');
        $q->execute([$id,$idCarrera]);
        if ($q->fetchColumn()) responder(['exito'=>false,'mensaje'=>'No puedes cambiar la carrera: hay solicitudes activas de estudiantes de otra carrera.']);
    }
    if ($accion==='crear') { $q=$pdo->prepare('INSERT INTO materias(nombre,descripcion,id_carrera) VALUES (?,?,?)');$q->execute([$nombre,$descripcion,$idCarrera]); }
    else { $q=$pdo->prepare('UPDATE materias SET nombre=?,descripcion=?,id_carrera=? WHERE id=?');$q->execute([$nombre,$descripcion,$idCarrera,$id]); }
    responder(['exito'=>true]);
} catch (PDOException $e) { responder(['exito'=>false,'mensaje'=>mensajeErrorDB($e,'No se pudo guardar la materia.')]); }
