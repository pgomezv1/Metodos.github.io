<?php
require_once __DIR__ . '/_common.php';
$idTutor=exigirRol('tutor');
if ($_SERVER['REQUEST_METHOD']!=='POST') responder(['exito'=>false,'mensaje'=>'Método no permitido.'],405);
$accion=$_POST['accion'] ?? '';
try {
    if ($accion==='obtener_mis_asignaciones') {
        $q=$pdo->prepare('SELECT s.id,s.fecha_especifica,s.estado,m.nombre AS materia,h.dia_semana,h.hora_inicio,h.hora_fin,a.nombre AS alumno FROM solicitudes s JOIN materias m ON m.id=s.id_materia JOIN horarios h ON h.id=s.id_horario JOIN usuarios a ON a.id=s.id_alumno WHERE s.id_tutor=? ORDER BY CASE WHEN s.estado="confirmada" THEN 0 ELSE 1 END,s.fecha_especifica DESC');
        $q->execute([$idTutor]);
        responder(['asignaciones'=>$q->fetchAll(PDO::FETCH_ASSOC),'tutor'=>['nombre'=>$_SESSION['nombre'],'carne'=>$_SESSION['carne']]]);
    }
    if ($accion==='marcar_completada') {
        $id=numero($_POST['id'] ?? 0);
        $q=$pdo->prepare("UPDATE solicitudes SET estado='completada' WHERE id=? AND id_tutor=? AND estado='confirmada' AND fecha_especifica <= CURDATE()");
        $q->execute([$id,$idTutor]);
        responder(['exito'=>$q->rowCount()>0,'mensaje'=>$q->rowCount()?'Tutoría finalizada.':'Solo puedes completar una tutoría confirmada cuya fecha ya haya llegado.']);
    }
    responder(['exito'=>false,'mensaje'=>'Acción inválida.']);
} catch (PDOException $e) { responder(['exito'=>false,'mensaje'=>'Error al consultar tutorías.']); }
