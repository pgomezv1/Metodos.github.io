<?php
require_once __DIR__ . '/_common.php';
exigirRol('admin');
try {
    if ($_SERVER['REQUEST_METHOD']==='GET') {
        $sql='SELECT s.id,s.id_materia,s.id_tutor,s.fecha_especifica,s.estado,m.nombre AS materia,h.dia_semana,h.hora_inicio,h.hora_fin,a.nombre AS alumno,c.nombre AS carrera,t.nombre AS tutor FROM solicitudes s JOIN materias m ON m.id=s.id_materia JOIN horarios h ON h.id=s.id_horario JOIN usuarios a ON a.id=s.id_alumno LEFT JOIN carreras c ON c.id=a.id_carrera LEFT JOIN usuarios t ON t.id=s.id_tutor ORDER BY CASE WHEN s.estado="pendiente" THEN 0 ELSE 1 END,s.fecha_especifica';
        $solicitudes=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        $tutores=$pdo->query("SELECT id,nombre FROM usuarios WHERE rol='tutor' AND activo=1 ORDER BY nombre")->fetchAll(PDO::FETCH_ASSOC);
        $relaciones=$pdo->query('SELECT tm.id_tutor,tm.id_materia FROM tutor_materia tm JOIN materias m ON m.id=tm.id_materia AND m.activo=1')->fetchAll(PDO::FETCH_ASSOC);
        responder(['solicitudes'=>$solicitudes,'tutores'=>$tutores,'relaciones'=>$relaciones]);
    }
    if ($_SERVER['REQUEST_METHOD']!=='POST') responder(['exito'=>false,'mensaje'=>'Método no permitido.'],405);
    $accion=$_POST['accion'] ?? '';
    $idSolicitud=numero($_POST['id_solicitud'] ?? 0);
    if ($accion==='rechazar') {
        $q=$pdo->prepare("UPDATE solicitudes SET estado='rechazada',id_tutor=NULL WHERE id=? AND estado='pendiente'");$q->execute([$idSolicitud]);
        responder(['exito'=>$q->rowCount()>0,'mensaje'=>$q->rowCount()?'Solicitud rechazada.':'Solo se pueden rechazar solicitudes pendientes.']);
    }
    if ($accion!=='asignar_tutor') responder(['exito'=>false,'mensaje'=>'Acción inválida.']);
    $idTutor=numero($_POST['id_tutor'] ?? 0);
    if (!$idSolicitud || !$idTutor) responder(['exito'=>false,'mensaje'=>'Selecciona una solicitud y un tutor.']);
    $pdo->beginTransaction();
    $q=$pdo->prepare('SELECT s.id,s.id_materia,s.fecha_especifica,s.id_horario,s.estado FROM solicitudes s WHERE s.id=? FOR UPDATE');
    $q->execute([$idSolicitud]);$sol=$q->fetch(PDO::FETCH_ASSOC);
    if (!$sol || !in_array($sol['estado'],['pendiente','confirmada'],true)) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'La solicitud no está disponible para asignación.']); }
    // Bloquear el tutor impide que dos administradores lo asignen simultáneamente a la misma hora.
    $q=$pdo->prepare("SELECT id FROM usuarios WHERE id=? AND rol='tutor' AND activo=1 FOR UPDATE");$q->execute([$idTutor]);
    if (!$q->fetchColumn()) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'Tutor inactivo o inexistente.']); }
    $q=$pdo->prepare('SELECT COUNT(*) FROM tutor_materia tm JOIN materias m ON m.id=tm.id_materia AND m.activo=1 WHERE tm.id_tutor=? AND tm.id_materia=?');$q->execute([$idTutor,$sol['id_materia']]);
    if (!$q->fetchColumn()) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'Este profesor no está autorizado para impartir la materia.']); }
    if (!horarioValido($pdo,$sol['id_horario'],$sol['fecha_especifica'])) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'El día o bloque de la solicitud no es válido.']); }
    $q=$pdo->prepare('SELECT COUNT(*) FROM solicitudes s JOIN horarios ocupado ON ocupado.id=s.id_horario JOIN horarios nuevo ON nuevo.id=? WHERE s.id_tutor=? AND s.fecha_especifica=? AND s.estado="confirmada" AND s.id<>? AND ocupado.hora_inicio<nuevo.hora_fin AND ocupado.hora_fin>nuevo.hora_inicio');
    $q->execute([$sol['id_horario'],$idTutor,$sol['fecha_especifica'],$idSolicitud]);
    if ((int)$q->fetchColumn()>0) { $pdo->rollBack(); responder(['exito'=>false,'mensaje'=>'El tutor ya tiene una tutoría confirmada que se cruza con ese horario.']); }
    $q=$pdo->prepare("UPDATE solicitudes SET id_tutor=?,estado='confirmada' WHERE id=?");$q->execute([$idTutor,$idSolicitud]);
    $pdo->commit();responder(['exito'=>true]);
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    responder(['exito'=>false,'mensaje'=>'No se pudo guardar la asignación.']);
}
