<?php
require_once __DIR__ . '/_common.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') responder(['exito'=>false,'mensaje'=>'Método no permitido.'],405);
$carne=trim($_POST['carne'] ?? '');$contrasena=$_POST['contrasena'] ?? '';
if ($carne==='' || $contrasena==='') responder(['exito'=>false,'mensaje'=>'Completa todos los campos.']);
try {
    // Admite carné o correo, conservando compatibilidad con el formulario del proyecto.
    $q=$pdo->prepare('SELECT id,carne,nombre,contrasena,rol FROM usuarios WHERE (carne=:ident OR correo=:email) AND activo=1 LIMIT 1');
    $q->execute([':ident'=>$carne,':email'=>$carne]);$u=$q->fetch(PDO::FETCH_ASSOC);
    if (!$u || !password_verify($contrasena,$u['contrasena'])) responder(['exito'=>false,'mensaje'=>'Credenciales incorrectas.']);
    session_regenerate_id(true);
    $_SESSION['usuario_id']=(int)$u['id'];$_SESSION['carne']=$u['carne'];$_SESSION['nombre']=$u['nombre'];$_SESSION['rol']=$u['rol'];
    $destinos=['admin'=>'admin.html','alumno'=>'alumno.html','tutor'=>'tutor.html'];
    responder(['exito'=>true,'redireccion'=>$destinos[$u['rol']]]);
} catch (PDOException $e) { responder(['exito'=>false,'mensaje'=>'No se pudo iniciar sesión.']); }
