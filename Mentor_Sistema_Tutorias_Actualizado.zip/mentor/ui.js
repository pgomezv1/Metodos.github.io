/* Interacciones de presentación — no reemplaza las APIs ni modifica datos. */
(() => {
  const layout = document.querySelector('.app-layout');
  const toggle = document.getElementById('menuToggle');
  const overlay = document.getElementById('sidebarOverlay');
  const closeMenu = () => {
    layout?.classList.remove('sidebar-open');
    toggle?.setAttribute('aria-expanded', 'false');
  };
  toggle?.addEventListener('click', () => {
    const visible = layout.classList.toggle('sidebar-open');
    toggle.setAttribute('aria-expanded', String(visible));
  });
  overlay?.addEventListener('click', closeMenu);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
  document.querySelectorAll('.sidebar-nav a').forEach(a => a.addEventListener('click', closeMenu));

  const dateSlot = document.getElementById('todayDate');
  if (dateSlot) dateSlot.textContent = new Intl.DateTimeFormat('es-GT', {
    weekday: 'long', day: 'numeric', month: 'long'
  }).format(new Date());

  // Filtrado local de tablas que se llenan asíncronamente con PHP.
  document.querySelectorAll('.table-panel').forEach(panel => {
    const input = panel.querySelector('[data-table-search]');
    const select = panel.querySelector('#filtroEstado');
    const tbody = panel.querySelector('tbody');
    if (!tbody) return;
    const filter = () => {
      const query = (input?.value || '').trim().toLocaleLowerCase('es');
      const state = select?.value || 'todos';
      tbody.querySelectorAll('tr').forEach(row => {
        const text = (row.textContent || '').toLocaleLowerCase('es');
        const statusMatches = state === 'todos' || row.querySelector('.estado-' + state) !== null;
        const searchMatches = !query || text.includes(query);
        row.hidden = !(statusMatches && searchMatches);
      });
    };
    input?.addEventListener('input', filter);
    select?.addEventListener('change', filter);
    const observer = new MutationObserver(filter);
    observer.observe(tbody, { childList: true });
  });
})();
