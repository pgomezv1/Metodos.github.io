(() => {
 const {get,post,escape,params,showError}=mentor;
 const tbody=document.querySelector('#tablaSolicitudes'),form=document.querySelector('#formAsignacion');
 const select=document.querySelector('#listaTutores'),info=document.querySelector('#info_solicitud');
 const filtro=document.querySelector('#filtroEstado');
 let solicitudes=[],tutores=[],relaciones=[];
 function pintar(){
  const val=(filtro?.value||'todos').toLowerCase();
  const texto=(document.querySelector('[data-table-search]')?.value||'').trim().toLowerCase();
  const lista=solicitudes.filter(s=>(val==='todos'||s.estado===val) && (!texto || [s.alumno,s.materia,s.tutor,s.carrera,s.fecha_especifica].join(' ').toLowerCase().includes(texto)));
  tbody.innerHTML=lista.map(s=>{
   let btn='';
   if(s.estado==='pendiente')btn=`<button data-assign="${s.id}">Asignar</button> <button data-reject="${s.id}">Rechazar</button>`;
   else if(s.estado==='confirmada')btn=`<button data-assign="${s.id}">Reasignar</button>`;
   else btn='<span class="muted">Sin acciones</span>';
   return `<tr><td>#${s.id}</td><td>${escape(s.alumno)}<small style="display:block">${escape(s.carrera||'')}</small></td><td>${escape(s.materia)}</td><td>${escape(s.fecha_especifica)}<br><small>${escape(s.hora_inicio?.slice(0,5)||'')}–${escape(s.hora_fin?.slice(0,5)||'')}</small></td><td>${escape(s.tutor||'Por asignar')}</td><td class="estado-${escape(s.estado)}">${escape(s.estado).toUpperCase()}</td><td>${btn}</td></tr>`;
  }).join('')||'<tr><td colspan="7" class="empty-filter">No hay solicitudes con esos filtros.</td></tr>';
 }
 async function cargarDatos(){
  const d=await get('api/solicitudes.php');solicitudes=d.solicitudes;tutores=d.tutores;relaciones=d.relaciones;
  pintar();
 }
 function preparar(s){
  document.querySelector('#id_solicitud').value=s.id;
  info.value=`#${s.id} | ${s.alumno} | ${s.materia}`;
  const disponibles=new Set(relaciones.filter(r=>Number(r.id_materia)===Number(s.id_materia)).map(r=>Number(r.id_tutor)));
  const candidatos=tutores.filter(t=>disponibles.has(Number(t.id)));
  select.innerHTML='<option value="">-- Seleccione un tutor --</option>'+candidatos.map(t=>`<option value="${t.id}">${escape(t.nombre)}</option>`).join('');
  if(!candidatos.length) select.innerHTML='<option value="">No hay profesores habilitados para esta materia</option>';
  select.disabled=!candidatos.length;
  document.querySelector('#btnAsignar').disabled=!candidatos.length;
  document.querySelector('#btnCancelar').style.display='inline-block';
  document.querySelector('#formAsignacion').scrollIntoView({behavior:'smooth',block:'center'});
 }
 function cancelar(){form.reset();document.querySelector('#id_solicitud').value='';info.value='Ninguna seleccionada';select.innerHTML='<option value="">-- Seleccione una solicitud --</option>';select.disabled=true;document.querySelector('#btnAsignar').disabled=true;document.querySelector('#btnCancelar').style.display='none';}
 tbody.addEventListener('click',async e=>{
  const assign=e.target.closest('[data-assign]'),reject=e.target.closest('[data-reject]');
  if(assign){const s=solicitudes.find(x=>Number(x.id)===Number(assign.dataset.assign));if(s)preparar(s);}
  if(reject && confirm('¿Rechazar esta solicitud?')){
   try{await post('api/solicitudes.php',params({accion:'rechazar',id_solicitud:reject.dataset.reject}));cancelar();await cargarDatos();}catch(err){showError(err);}
  }
 });
 form.addEventListener('submit',async e=>{e.preventDefault();try{await post('api/solicitudes.php',new FormData(form));cancelar();await cargarDatos();}catch(err){showError(err);}});
 document.querySelector('#btnCancelar').addEventListener('click',cancelar);
 filtro?.addEventListener('change',pintar);
 document.querySelector('[data-table-search]')?.addEventListener('input',pintar);
 cargarDatos().catch(showError);
})();
