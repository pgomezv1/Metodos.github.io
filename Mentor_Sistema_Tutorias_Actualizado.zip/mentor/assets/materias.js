(() => {
 const {get,post,escape,params,showError}=mentor;
 const form=document.querySelector('#formMateria'), tbody=document.querySelector('#tablaMaterias'), select=document.querySelector('#id_carrera');
 let materias=[];
 async function cargarCarreras() {
   const carreras=await get('api/carreras.php');
   select.innerHTML='<option value="">Selecciona una carrera</option>'+carreras.map(c=>`<option value="${c.id}">${escape(c.nombre)}</option>`).join('');
 }
 async function cargarMaterias() {
   materias=await get('api/materias.php');
   tbody.innerHTML=materias.map(m=>`<tr><td>${m.id}</td><td><b>${escape(m.nombre)}</b></td><td>${escape(m.carrera||'Sin asignar')}</td><td>${escape(m.descripcion||'—')}</td><td><button data-edit="${m.id}">Editar</button><button data-delete="${m.id}">Desactivar</button></td></tr>`).join('')||'<tr><td colspan="5">No se han registrado materias.</td></tr>';
 }
 function cancelar() {
   form.reset();form.elements.namedItem('accion').value='crear';form.elements.namedItem('id').value='';
   document.querySelector('#tituloFormulario').textContent='Agregar nueva materia';
   document.querySelector('#btnGuardar').textContent='Guardar materia';
   document.querySelector('#btnCancelar').style.display='none';
 }
 tbody.addEventListener('click',async e=>{
   const edit=e.target.closest('[data-edit]'),del=e.target.closest('[data-delete]');
   if(edit){const m=materias.find(x=>+x.id===+edit.dataset.edit);if(!m)return;
     form.elements.namedItem('accion').value='editar';form.elements.namedItem('id').value=m.id;form.elements.namedItem('nombre').value=m.nombre;form.elements.namedItem('descripcion').value=m.descripcion||'';select.value=m.id_carrera||'';
     document.querySelector('#tituloFormulario').textContent='Editar materia';document.querySelector('#btnGuardar').textContent='Actualizar materia';document.querySelector('#btnCancelar').style.display='inline-block';
     document.querySelector('#form-panel').scrollIntoView({behavior:'smooth'});
   }
   if(del && confirm('¿Desactivar esta materia? Sus tutorías históricas se conservarán.')){
     try {await post('api/materias.php',params({accion:'eliminar',id:del.dataset.delete}));await cargarMaterias();}catch(err){showError(err);}
   }
 });
 document.querySelector('#btnCancelar').addEventListener('click',cancelar);
 form.addEventListener('submit',async e=>{e.preventDefault();try{await post('api/materias.php',new FormData(form));cancelar();await cargarMaterias();}catch(err){showError(err);}});
 Promise.all([cargarCarreras(),cargarMaterias()]).catch(showError);
})();
