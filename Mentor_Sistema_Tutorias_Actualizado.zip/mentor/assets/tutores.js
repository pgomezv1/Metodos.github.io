(() => {
 const {get,post,escape,showError}=mentor;
 const sel=document.querySelector('#tutorSelect'),contenedor=document.querySelector('#listaMateriasTutor');
 let datos;
 async function actualizar() {
   datos=await get('api/tutores_materias.php');
   const seleccionado=sel.value;
   sel.innerHTML='<option value="">Seleccione un tutor</option>'+datos.tutores.map(t=>`<option value="${t.id}">${escape(t.nombre)} · ${escape(t.carne)}</option>`).join('');
   if(datos.tutores.some(t=>String(t.id)===seleccionado))sel.value=seleccionado;
   actualizarLista();
 }
 function actualizarLista(){
   const id=Number(sel.value);if(!id){contenedor.innerHTML='<p class="muted">Selecciona un tutor para gestionar las materias que puede impartir.</p>';return;}
   if(!datos.materias.length){contenedor.innerHTML='<p class="muted">Primero debes registrar carreras y materias.</p>';return;}
   const asignadas=new Set(datos.relaciones.filter(r=>Number(r.id_tutor)===id).map(r=>Number(r.id_materia)));
   const agrupadas=Object.groupBy?Object.groupBy(datos.materias,m=>m.carrera):datos.materias.reduce((a,m)=>((a[m.carrera]??=[]).push(m),a),{});
   contenedor.innerHTML=Object.entries(agrupadas).map(([c,materias])=>`<fieldset class="mentor-check-group"><legend>${escape(c)}</legend><div class="mentor-check-grid">${materias.map(m=>`<label class="mentor-check"><input type="checkbox" name="materias[]" value="${m.id}" ${asignadas.has(Number(m.id))?'checked':''}><span>${escape(m.nombre)}</span></label>`).join('')}</div></fieldset>`).join('');
 }
 sel.addEventListener('change',actualizarLista);
 document.querySelector('#formTutores').addEventListener('submit',async e=>{
   e.preventDefault();if(!sel.value){alert('Seleccione un tutor.');return;}
   const formData=new FormData(e.currentTarget);formData.set('accion','guardar');
   try{await post('api/tutores_materias.php',formData);await actualizar();document.querySelector('#mensajeGuardado').textContent='✓ Asignaciones actualizadas correctamente.';}catch(err){showError(err);}
 });
 actualizar().catch(showError);
})();
