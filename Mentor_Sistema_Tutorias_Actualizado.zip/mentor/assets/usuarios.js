(() => {
 const {get,post,escape,params,showError}=window.mentor;
 const form=document.querySelector('#formUsuario');
 const tbody=document.querySelector('#tablaUsuarios');
 const selCarrera=document.querySelector('#id_carrera');
 const areaCarrera=document.querySelector('#campoCarrera');
 let usuarios=[];
 function carreraSegunRol() {
   const esAlumno=form.elements.namedItem('rol').value==='alumno';
   areaCarrera.hidden=!esAlumno;
   selCarrera.required=esAlumno;
   if(!esAlumno) selCarrera.value='';
 }
 async function cargarCarreras() {
   const carreras=await get('api/carreras.php');
   selCarrera.innerHTML='<option value="">Seleccione una carrera</option>'+carreras.map(c=>`<option value="${c.id}">${escape(c.nombre)}</option>`).join('');
 }
 async function cargarUsuarios() {
   usuarios=await get('api/usuarios.php');
   tbody.innerHTML=usuarios.map(u=>`<tr><td>${u.id}</td><td>${escape(u.carne)}</td><td>${escape(u.nombre)}<small style="display:block">${escape(u.correo || '')}</small></td><td>${escape(u.rol)}</td><td>${escape(u.carrera || '—')}</td><td><span class="status-chip ${u.activo==1?'estado-confirmada':'estado-cancelada'}">${u.activo==1?'Activo':'Inactivo'}</span></td><td><button data-edit="${u.id}">Editar</button><button data-toggle="${u.id}" data-active="${u.activo}">${u.activo==1?'Desactivar':'Reactivar'}</button></td></tr>`).join('') || '<tr><td colspan="7">No hay usuarios.</td></tr>';
 }
 function editar(u) {
   form.elements.namedItem('accion').value='editar';form.elements.namedItem('id').value=u.id;form.elements.namedItem('carne').value=u.carne;form.elements.namedItem('nombre').value=u.nombre;form.elements.namedItem('correo').value=u.correo||'';form.elements.namedItem('rol').value=u.rol;
   carreraSegunRol();selCarrera.value=u.id_carrera || '';
   form.elements.namedItem('contrasena').value='';form.elements.namedItem('contrasena').required=false;
   document.querySelector('#nota_password').style.display='inline';
   document.querySelector('#tituloFormulario').textContent='Editar usuario';
   document.querySelector('#btnGuardar').textContent='Actualizar usuario';
   document.querySelector('#btnCancelar').style.display='inline-block';
   document.querySelector('#form-panel').scrollIntoView({behavior:'smooth',block:'start'});
 }
 function cancelarEdicion() {
   form.reset();form.elements.namedItem('accion').value='crear';form.elements.namedItem('id').value='';form.elements.namedItem('contrasena').required=true;
   document.querySelector('#nota_password').style.display='none';
   document.querySelector('#tituloFormulario').textContent='Agregar nuevo usuario';
   document.querySelector('#btnGuardar').textContent='Guardar usuario';
   document.querySelector('#btnCancelar').style.display='none';
   carreraSegunRol();
 }
 tbody.addEventListener('click',async e=>{
   const edit=e.target.closest('[data-edit]');const toggle=e.target.closest('[data-toggle]');
   if(edit) {const u=usuarios.find(x=>Number(x.id)===Number(edit.dataset.edit));if(u) editar(u);}
   if(toggle) {
     const accion=toggle.dataset.active==='1'?'eliminar':'reactivar';
     if(!confirm(`${accion==='eliminar'?'¿Desactivar':'¿Reactivar'} este usuario?`)) return;
     try {await post('api/usuarios.php',params({accion,id:toggle.dataset.toggle}));await cargarUsuarios();}catch(err){showError(err);}
   }
 });
 form.elements.namedItem('rol').addEventListener('change',carreraSegunRol);
 document.querySelector('#btnCancelar').addEventListener('click',cancelarEdicion);
 form.addEventListener('submit',async e=>{
   e.preventDefault();try {await post('api/usuarios.php',new FormData(form));cancelarEdicion();await cargarUsuarios();}catch(err){showError(err);}
 });
 Promise.all([cargarCarreras(),cargarUsuarios()]).catch(showError);
 carreraSegunRol();
})();
