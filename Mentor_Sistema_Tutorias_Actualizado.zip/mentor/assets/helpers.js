// Funciones mínimas compartidas de los módulos de Mentor.
window.mentor = {
  escape(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); },
  async get(url) {
    const r=await fetch(url,{credentials:'same-origin',cache:'no-store'});
    const data=await r.json();
    if(!r.ok || data?.exito===false) throw new Error(data?.mensaje || 'No se pudo consultar la información.');
    return data;
  },
  async post(url,body) {
    const r=await fetch(url,{method:'POST',body,credentials:'same-origin'});
    const data=await r.json();
    if(!r.ok || data?.exito===false) throw new Error(data?.mensaje || 'No se pudo procesar la solicitud.');
    return data;
  },
  params(obj) { const f=new FormData();Object.entries(obj).forEach(([k,v])=>f.append(k,v));return f; },
  showError(err) { alert(err.message || 'No se completó la operación.'); }
};
