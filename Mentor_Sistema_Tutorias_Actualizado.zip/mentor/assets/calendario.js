/* Mentor: calendario real conectado a PHP/MySQL, con vistas mes/semana/agenda. */
(() => {
 const {get,escape}=mentor;
 const locale='es-GT';
 const hoy=new Date();hoy.setHours(12,0,0,0);
 let cursor=new Date(hoy),vista='month',eventos=[],rol='',seleccion=iso(hoy);
 const dias=['LUN','MAR','MIÉ','JUE','VIE','SÁB','DOM'];
 const $=id=>document.getElementById(id);
 function iso(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
 function parse(s){const [a,m,d]=s.split('-').map(Number);return new Date(a,m-1,d,12);}
 function sumarDias(d,numero){const t=new Date(d);t.setDate(t.getDate()+numero);return t;}
 function lunes(d){return sumarDias(d,-((d.getDay()+6)%7));}
 function primeroMes(d){return new Date(d.getFullYear(),d.getMonth(),1,12);}
 function ultimoMes(d){return new Date(d.getFullYear(),d.getMonth()+1,0,12);}
 function rango(){
  if(vista==='week'){const l=lunes(cursor);return [l,sumarDias(l,6)];}
  return [lunes(primeroMes(cursor)),sumarDias(lunes(ultimoMes(cursor)),6)];
 }
 function fechaTitulo(d,options){return new Intl.DateTimeFormat(locale,options).format(d);}
 function iconoEstado(e){return {'pendiente':'⏱','confirmada':'✓','completada':'★','cancelada':'×','rechazada':'×'}[e.estado]||'•';}
 function etiquetaEvento(e){return (e.hora_inicio||'').slice(0,5)+' · '+e.materia;}
 function estadoClase(e){return ['pendiente','confirmada','completada','cancelada','rechazada'].includes(e.estado)?e.estado:'pendiente';}
 function itemsDeDia(date){return eventos.filter(e=>e.fecha_especifica===date);}
 function calendarioMensual(){
  const [desde,hasta]=rango();let html='';
  for(let d=new Date(desde);d<=hasta;d=sumarDias(d,1)){
   const f=iso(d),deOtroMes=d.getMonth()!==cursor.getMonth();const lista=itemsDeDia(f);
   html+=`<div class="cal-cell ${deOtroMes?'cal-outside':''} ${f===iso(hoy)?'cal-today':''} ${f===seleccion?'cal-selected':''}" data-day="${f}" role="button" tabindex="0" aria-label="${escape(fechaTitulo(d,{weekday:'long',day:'numeric',month:'long'}))}, ${lista.length} tutorías"><div class="cal-number"><span>${d.getDate()}</span>${f===iso(hoy)?'<i>Hoy</i>':''}</div><div class="cal-events">${lista.slice(0,3).map(e=>`<div class="cal-event ${estadoClase(e)}" title="${escape(e.materia+' · '+e.estado)}"><b>${iconoEstado(e)}</b><span>${escape(etiquetaEvento(e))}</span></div>`).join('')}${lista.length>3?`<span class="cal-more">+${lista.length-3} más</span>`:''}</div></div>`;
  }
  $('calendarGrid').innerHTML=html;
 }
 function calendarioSemanal(){
  const [desde,hasta]=rango();let html='';
  for(let d=new Date(desde);d<=hasta;d=sumarDias(d,1)){
   const f=iso(d),lista=itemsDeDia(f);
   html+=`<div class="cal-cell cal-week-cell ${f===iso(hoy)?'cal-today':''} ${f===seleccion?'cal-selected':''}" data-day="${f}" role="button" tabindex="0"><div class="cal-number">${fechaTitulo(d,{weekday:'short',day:'numeric'})}</div><div class="cal-events">${lista.map(e=>`<div class="cal-event ${estadoClase(e)}" title="${escape(e.materia+' · '+e.estado)}"><b>${iconoEstado(e)}</b><span>${escape(etiquetaEvento(e))}</span></div>`).join('')}</div></div>`;
  }
  $('calendarGrid').innerHTML=html;
 }
 function calendarioAgenda(){
  const lista=eventos.slice().sort((a,b)=>a.fecha_especifica.localeCompare(b.fecha_especifica)||a.hora_inicio.localeCompare(b.hora_inicio));
  $('calendarAgenda').innerHTML=lista.length?lista.map(e=>`<article class="agenda-item ${estadoClase(e)}"><div class="agenda-date"><strong>${parse(e.fecha_especifica).getDate()}</strong><span>${fechaTitulo(parse(e.fecha_especifica),{month:'short'})}</span></div><div class="agenda-info"><strong>${escape(e.materia)}</strong><small>${escape(e.hora_inicio.slice(0,5))}–${escape(e.hora_fin.slice(0,5))} · ${escape(rol==='tutor'?e.alumno:(e.tutor||'Por asignar'))}</small></div><span class="agenda-status estado-${estadoClase(e)}">${escape(e.estado)}</span></article>`).join(''):'<div class="calendar-emptystate">No hay tutorías para este período.</div>';
 }
 function pintarMesMini(){
  $('miniMonthLabel').textContent=fechaTitulo(cursor,{month:'long',year:'numeric'});
  const a=lunes(primeroMes(cursor)),b=sumarDias(lunes(ultimoMes(cursor)),6);
  let html='';for(let d=new Date(a);d<=b;d=sumarDias(d,1)){
   const f=iso(d);html+=`<button type="button" data-mini="${f}" class="${d.getMonth()!==cursor.getMonth()?'muted':''} ${f===iso(hoy)?'today':''} ${f===seleccion?'selected':''}">${d.getDate()}${itemsDeDia(f).length?'<i></i>':''}</button>`;
  }$('miniCalendar').innerHTML=html;
 }
 function detalleDia(){
  const d=parse(seleccion);$('selectedDateLabel').textContent=fechaTitulo(d,{weekday:'long',day:'numeric',month:'long'});
  const lista=itemsDeDia(seleccion);
  $('dayEventList').innerHTML=lista.length?lista.map(e=>`<article class="day-event ${estadoClase(e)}"><span class="day-event-time">${escape(e.hora_inicio.slice(0,5))} – ${escape(e.hora_fin.slice(0,5))}</span><strong>${escape(e.materia)}</strong><small>${escape(rol==='tutor'?e.alumno:rol==='admin'?`${e.alumno} / ${e.tutor||'Sin asignar'}`:e.tutor||'Por asignar')}</small><span class="status-chip estado-${estadoClase(e)}">${escape(e.estado)}</span></article>`).join(''):'<div class="day-event-empty">Sin tutorías registradas este día.</div>';
 }
 function render(){
  const [desde,hasta]=rango();
  $('calendarMonthTitle').textContent=vista==='week'?`${fechaTitulo(desde,{day:'numeric',month:'short'})} – ${fechaTitulo(hasta,{day:'numeric',month:'short',year:'numeric'})}`:fechaTitulo(cursor,{month:'long',year:'numeric'});
  $('calendarGrid').hidden=vista==='agenda';$('calendarAgenda').hidden=vista!=='agenda';
  document.querySelector('.calendar-weekdays').hidden=vista==='agenda';
  $('calendarGrid').classList.toggle('weekly',vista==='week');
  if(vista==='agenda')calendarioAgenda();else if(vista==='week')calendarioSemanal();else calendarioMensual();
  document.querySelectorAll('[data-view]').forEach(b=>{b.classList.toggle('selected',b.dataset.view===vista);b.setAttribute('aria-pressed',String(b.dataset.view===vista));});
  pintarMesMini();detalleDia();
 }
 function navegar(n){cursor=vista==='week'?sumarDias(cursor,n*7):new Date(cursor.getFullYear(),cursor.getMonth()+n,1,12);seleccion=iso(cursor);actualizar();}
 function setNav(){
  const adm=[['Inicio','admin.html'],['Usuarios','usuarios.html'],['Carreras','carreras.html'],['Materias','materias.html'],['Tutores','tutores.html'],['Horarios','horarios.html'],['Solicitudes','solicitudes.html'],['Calendario','calendario.html']];
  const opciones=rol==='admin'?adm:rol==='alumno'?[['Mis tutorías','alumno.html'],['Calendario','calendario.html']]:[['Mi agenda','tutor.html'],['Calendario','calendario.html']];
  document.querySelector('.sidebar-nav').innerHTML=opciones.map(([label,url])=>`<a class="nav-link ${url==='calendario.html'?'active':''}" href="${url}"><span class="nav-emoji">${{'Inicio':'⌂','Usuarios':'♙','Carreras':'🎓','Materias':'▤','Tutores':'♧','Horarios':'◷','Solicitudes':'☷','Calendario':'▦','Mis tutorías':'▤','Mi agenda':'▤'}[label]}</span><span>${label}</span></a>`).join('');
  document.querySelector('.user-pill-copy b').textContent=rol==='admin'?'Administración':rol==='alumno'?'Estudiante':'Docente';
  $('calendarSubtitle').textContent=rol==='tutor'?'Aquí aparecen exclusivamente las tutorías confirmadas que debes impartir.':rol==='alumno'?'Consulta tus solicitudes pendientes y confirmadas, identificadas por colores.':'Revisa todas las solicitudes y sus estados en un solo lugar.';
  $('legendAdmin').hidden=rol!=='admin';document.querySelector('.legend-dot.pending').parentElement.hidden=rol==='tutor';
 }
 async function actualizar(){
  const [desde,hasta]=rango();$('calendarMessage').textContent='Actualizando calendario…';
  try{
    const d=await get(`api/calendario.php?desde=${iso(desde)}&hasta=${iso(hasta)}`);
    eventos=d.eventos;rol=d.rol;setNav();render();$('calendarMessage').textContent=`${eventos.length} ${eventos.length===1?'tutoría':'tutorías'} en el período mostrado`;
  }catch(err){$('calendarMessage').textContent=err.message;$('calendarGrid').innerHTML='<p class="calendar-emptystate">No se pudo cargar el calendario.</p>';
   if(/Sesión|autorizado/.test(err.message))setTimeout(()=>location.assign('index.html'),800);
  }
 }
 $('calendarGrid').addEventListener('click',e=>{const c=e.target.closest('[data-day]');if(c){seleccion=c.dataset.day;render();}});
 $('calendarGrid').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){const c=e.target.closest('[data-day]');if(c){e.preventDefault();seleccion=c.dataset.day;render();}}});
 $('miniCalendar').addEventListener('click',e=>{const b=e.target.closest('[data-mini]');if(!b)return;const d=parse(b.dataset.mini);seleccion=b.dataset.mini;if(d.getMonth()!==cursor.getMonth()||d.getFullYear()!==cursor.getFullYear()){cursor=d;actualizar();}else if(vista==='week'&&iso(lunes(d))!==iso(lunes(cursor))){cursor=d;actualizar();}else render();});
 $('calPrev').addEventListener('click',()=>navegar(-1));$('calNext').addEventListener('click',()=>navegar(1));
 $('miniPrev').addEventListener('click',()=>{cursor=new Date(cursor.getFullYear(),cursor.getMonth()-1,1,12);seleccion=iso(cursor);actualizar();});
 $('miniNext').addEventListener('click',()=>{cursor=new Date(cursor.getFullYear(),cursor.getMonth()+1,1,12);seleccion=iso(cursor);actualizar();});
 $('calToday').addEventListener('click',()=>{cursor=new Date(hoy);seleccion=iso(hoy);actualizar();});
 document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>{vista=b.dataset.view;actualizar();}));
 actualizar();
})();
