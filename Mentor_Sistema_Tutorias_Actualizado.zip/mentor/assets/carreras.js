(() => {
 const {get,post,escape,params,showError}=mentor;
 const form=document.querySelector('#formCarrera'),tbody=document.querySelector('#tablaCarreras');
 let carreras=[];
 async function actualizar() {
   carreras=await get('api/carreras.php?todos=1');
   tbody.innerHTML=carreras.map(c=>`<tr><td>${c.id}</td><td><b>${escape(c.nombre)}</b></td><td>${escape(c.descripcion||'—')}</td><td>${c.alumnos} alumnos</td><td>${c.materias} materias</td><td><span class="status-chip ${c.activo==1?'estado-confirmada':'estado-cancelada'}">${c.activo==1?'Activa':'Inactiva'}</span></td><td><button data-edit="${c.id}">Editar</button><button data-toggle="${c.id}" data-active="${c.activo}">${c.activo==1?'Desactivar':'Reactivar'}</button></td></tr>`).join('')||'<tr><td colspan="7">No hay carreras registradas.</td></tr>';
 }
 function limpiar() {form.reset();form.elements.namedItem('accion').value='crear';form.elements.namedItem('id').value='';document.querySelector('#tituloCarrera').textContent='Agregar carrera';document.querySelector('#btnCancelar').hidden=true;}
 tbody.addEventListener('click',async e=>{
   const ed=e.target.closest('[data-edit]'),tg=e.target.closest('[data-toggle]');
   if(ed){const c=carreras.find(x=>+x.id===+ed.dataset.edit);if(!c)return;form.elements.namedItem('id').value=c.id;form.elements.namedItem('accion').value='editar';form.elements.namedItem('nombre').value=c.nombre;form.elements.namedItem('descripcion').value=c.descripcion||'';document.querySelector('#tituloCarrera').textContent='Editar carrera';document.querySelector('#btnCancelar').hidden=false;form.scrollIntoView({behavior:'smooth'});}
   if(tg && confirm('¿Cambiar el estado de esta carrera?')){try{await post('api/carreras.php',params({accion:tg.dataset.active==='1'?'eliminar':'reactivar',id:tg.dataset.toggle}));await actualizar();}catch(err){showError(err);}}
 });
 document.querySelector('#btnCancelar').addEventListener('click',limpiar);
 form.addEventListener('submit',async e=>{e.preventDefault();try{await post('api/carreras.php',new FormData(form));limpiar();await actualizar();}catch(err){showError(err);}});
 actualizar().catch(showError);
})();
