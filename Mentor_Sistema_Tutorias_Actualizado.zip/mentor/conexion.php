<?php
require_once __DIR__ . '/vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$host = $_ENV['DB_HOST'];
$db   = $_ENV['DB_NAME'];
$user = $_ENV['DB_USER'];
$pass = $_ENV['DB_PASS'];

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // SEGURIDAD: Nunca mostrar $e->getMessage() en producción.
    // Opcional: error_log($e->getMessage()); // Lo guarda silenciosamente en el log del servidor de XAMPP
    die("Error crítico: No se pudo conectar a la base de datos. Contacte al soporte.");
}
?>