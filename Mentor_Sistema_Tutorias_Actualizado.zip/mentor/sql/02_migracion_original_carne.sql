-- Para instalaciones con carne/contrasena. Respaldar primero y NO ejecutar el SQL inicial.
-- Conserva todos los registros anteriores. Se puede ejecutar de nuevo sin duplicar columnas.
USE sistema_tutorias;
CREATE TABLE IF NOT EXISTS carreras (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(120) NOT NULL UNIQUE,
 descripcion TEXT NULL,
 activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
DELIMITER //
DROP PROCEDURE IF EXISTS mentor_migrar_original //
CREATE PROCEDURE mentor_migrar_original()
BEGIN
 IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='correo') THEN
   ALTER TABLE usuarios ADD COLUMN correo VARCHAR(100) NULL UNIQUE;
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='activo') THEN
   ALTER TABLE usuarios ADD COLUMN activo TINYINT(1) NOT NULL DEFAULT 1;
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='id_carrera') THEN
   ALTER TABLE usuarios ADD COLUMN id_carrera INT NULL;
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='id_carrera' AND REFERENCED_TABLE_NAME='carreras') THEN
   ALTER TABLE usuarios ADD CONSTRAINT fk_usuarios_carreras FOREIGN KEY (id_carrera) REFERENCES carreras(id);
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='materias' AND COLUMN_NAME='id_carrera') THEN
   ALTER TABLE materias ADD COLUMN id_carrera INT NULL;
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='materias' AND COLUMN_NAME='activo') THEN
   ALTER TABLE materias ADD COLUMN activo TINYINT(1) NOT NULL DEFAULT 1;
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='materias' AND COLUMN_NAME='id_carrera' AND REFERENCED_TABLE_NAME='carreras') THEN
   ALTER TABLE materias ADD CONSTRAINT fk_materias_carreras FOREIGN KEY (id_carrera) REFERENCES carreras(id);
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='horarios' AND COLUMN_NAME='activo') THEN
   ALTER TABLE horarios ADD COLUMN activo TINYINT(1) NOT NULL DEFAULT 1;
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='solicitudes' AND INDEX_NAME='idx_sol_alumno_fecha') THEN
   CREATE INDEX idx_sol_alumno_fecha ON solicitudes(id_alumno,fecha_especifica,estado);
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='solicitudes' AND INDEX_NAME='idx_sol_tutor_fecha') THEN
   CREATE INDEX idx_sol_tutor_fecha ON solicitudes(id_tutor,fecha_especifica,estado);
 END IF;
END //
DELIMITER ;
CALL mentor_migrar_original();
DROP PROCEDURE mentor_migrar_original;
CREATE TABLE IF NOT EXISTS tutor_materia (
 id_tutor INT NOT NULL, id_materia INT NOT NULL,
 PRIMARY KEY(id_tutor,id_materia),
 FOREIGN KEY(id_tutor) REFERENCES usuarios(id) ON DELETE CASCADE,
 FOREIGN KEY(id_materia) REFERENCES materias(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- La migración no inventa carrera para materias ni alumnos históricos; asígnalas en Mentor.
