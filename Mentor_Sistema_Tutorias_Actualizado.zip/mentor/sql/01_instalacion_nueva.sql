-- MENTOR · NUEVA INSTALACIÓN. No ejecutar sobre una base con datos.
-- Se conservan carne/contrasena de la aplicación real. Se añade correo opcional.
CREATE DATABASE IF NOT EXISTS sistema_tutorias CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_tutorias;

CREATE TABLE IF NOT EXISTS carreras (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  descripcion TEXT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_carreras_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  carne VARCHAR(100) NOT NULL UNIQUE,
  nombre VARCHAR(100) NOT NULL,
  correo VARCHAR(100) NULL UNIQUE,
  contrasena VARCHAR(255) NOT NULL,
  rol ENUM('admin','alumno','tutor') NOT NULL,
  id_carrera INT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_usuarios_carrera (id_carrera),
  CONSTRAINT fk_usuarios_carreras FOREIGN KEY (id_carrera) REFERENCES carreras(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS materias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT NULL,
  id_carrera INT NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_materias_carrera (id_carrera, activo),
  CONSTRAINT fk_materias_carreras FOREIGN KEY (id_carrera) REFERENCES carreras(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tutor_materia (
  id_tutor INT NOT NULL,
  id_materia INT NOT NULL,
  PRIMARY KEY (id_tutor,id_materia),
  KEY idx_tm_materia (id_materia),
  CONSTRAINT fk_tm_tutor FOREIGN KEY (id_tutor) REFERENCES usuarios(id) ON DELETE CASCADE,
  CONSTRAINT fk_tm_materia FOREIGN KEY (id_materia) REFERENCES materias(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS horarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dia_semana ENUM('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo') NOT NULL,
  hora_inicio TIME NOT NULL,
  hora_fin TIME NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_horarios_dia (dia_semana,activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS solicitudes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_alumno INT NOT NULL,
  id_materia INT NOT NULL,
  id_horario INT NOT NULL,
  id_tutor INT NULL,
  fecha_especifica DATE NOT NULL,
  estado ENUM('pendiente','confirmada','cancelada','completada','rechazada') NOT NULL DEFAULT 'pendiente',
  CONSTRAINT fk_sol_alumno FOREIGN KEY (id_alumno) REFERENCES usuarios(id),
  CONSTRAINT fk_sol_materia FOREIGN KEY (id_materia) REFERENCES materias(id),
  CONSTRAINT fk_sol_horario FOREIGN KEY (id_horario) REFERENCES horarios(id),
  CONSTRAINT fk_sol_tutor FOREIGN KEY (id_tutor) REFERENCES usuarios(id),
  KEY idx_sol_alumno_fecha (id_alumno,fecha_especifica,estado),
  KEY idx_sol_tutor_fecha (id_tutor,fecha_especifica,estado),
  KEY idx_sol_fecha (fecha_especifica,estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Crear el primer administrador mediante api/instalar_admin.php desde CLI,
-- o con un INSERT que use un hash generado por password_hash() en PHP.
