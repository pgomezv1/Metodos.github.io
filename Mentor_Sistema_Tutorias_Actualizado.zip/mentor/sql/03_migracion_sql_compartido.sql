-- Para base creada exactamente con el SQL compartido en el chat (correo/password).
-- Respaldar primero. Adapta a la lógica original del proyecto (carne/contrasena).
USE sistema_tutorias;
CREATE TABLE IF NOT EXISTS carreras (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(120) NOT NULL UNIQUE,
 descripcion TEXT NULL,
 activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
DELIMITER //
DROP PROCEDURE IF EXISTS mentor_migrar_sql_compartido //
CREATE PROCEDURE mentor_migrar_sql_compartido()
BEGIN
 IF EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='password') THEN
   ALTER TABLE usuarios CHANGE COLUMN `password` `contrasena` VARCHAR(255) NOT NULL;
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='carne') THEN
   ALTER TABLE usuarios ADD COLUMN carne VARCHAR(100) NULL;
 END IF;
 UPDATE usuarios SET carne=correo WHERE carne IS NULL;
 -- Los nuevos usuarios pueden registrarse solo con carné, como en la app original.
 ALTER TABLE usuarios MODIFY COLUMN correo VARCHAR(100) NULL;
 IF NOT EXISTS (SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='carne' AND NON_UNIQUE=0) THEN
   ALTER TABLE usuarios ADD UNIQUE KEY uq_usuarios_carne (carne);
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='id_carrera') THEN
   ALTER TABLE usuarios ADD COLUMN id_carrera INT NULL;
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='usuarios' AND COLUMN_NAME='id_carrera' AND REFERENCED_TABLE_NAME='carreras') THEN
   ALTER TABLE usuarios ADD CONSTRAINT fk_usuarios_carreras FOREIGN KEY (id_carrera) REFERENCES carreras(id);
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='materias' AND COLUMN_NAME='id_carrera') THEN
   ALTER TABLE materias ADD COLUMN id_carrera INT NULL;
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='materias' AND COLUMN_NAME='id_carrera' AND REFERENCED_TABLE_NAME='carreras') THEN
   ALTER TABLE materias ADD CONSTRAINT fk_materias_carreras FOREIGN KEY (id_carrera) REFERENCES carreras(id);
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='solicitudes' AND INDEX_NAME='idx_sol_alumno_fecha') THEN
   CREATE INDEX idx_sol_alumno_fecha ON solicitudes(id_alumno,fecha_especifica,estado);
 END IF;
 IF NOT EXISTS (SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='solicitudes' AND INDEX_NAME='idx_sol_tutor_fecha') THEN
   CREATE INDEX idx_sol_tutor_fecha ON solicitudes(id_tutor,fecha_especifica,estado);
 END IF;
END //
DELIMITER ;
CALL mentor_migrar_sql_compartido();
DROP PROCEDURE mentor_migrar_sql_compartido;
-- Los usuarios importados pueden entrar inicialmente usando su correo en campo carné.
-- Posteriormente, el administrador puede editar cada carné desde Usuarios.
-- Crear carreras y asignar carreras/materias antes de solicitar nuevas tutorías.
