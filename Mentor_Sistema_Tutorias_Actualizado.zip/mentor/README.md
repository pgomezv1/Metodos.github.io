# Mentor — Sistema de gestión de tutorías académicas

Esta versión amplía el proyecto PHP/MySQL original, conservando los roles `admin`, `alumno` y `tutor`, la autenticación por carné y la lógica principal de formularios y solicitudes.

## Novedades

- Calendario real (no simulado) con vistas **Mes / Semana / Agenda**, mini calendario y fechas seleccionables.
- Alumno: solo observa eventos **pendientes y confirmados**; solo puede solicitar materias de su carrera.
- Tutor: solo observa eventos **confirmados** que estén asignados a su usuario.
- Administrador: observa el calendario general con todos los estados.
- Panel de carreras: crear, editar, desactivar y reactivar.
- Alumnos: carrera obligatoria para registros nuevos; alumnos ya existentes deben vincularse tras la migración.
- Materias: se asignan a una carrera. Si Matemáticas está disponible en dos carreras, crea dos materias (una para cada carrera) y márcalas ambas en el perfil del tutor.
- Panel de tutores: tutor y materia tienen una relación muchos-a-muchos, sin restricción de carrera.
- Asignación de solicitudes: solo profesores autorizados para la materia; al asignar, se verifica que no haya cruce de horarios.
- Validación del día de semana, solicitud pasada, coincidencia de carrera y solapamientos en el servidor.
- Cambios de estado y desactivaciones lógicas para mantener datos históricos.
- Marca única **Mentor**.

## Instalación en XAMPP

1. **Respaldar** la base y la carpeta anteriores (exportación SQL desde phpMyAdmin).
2. Extraer la carpeta `mentor` bajo `C:\xampp\htdocs\mentor`.
3. Escoger **solo uno** de estos escenarios de base de datos:

   | Escenario | Script |
   |---|---|
   | No existe la BD; instalación completamente nueva | `sql/01_instalacion_nueva.sql` |
   | La BD ya existe y la tabla `usuarios` usa `carne` y `contrasena` | `sql/02_migracion_original_carne.sql` |
   | Se creó la BD con el SQL del chat (`correo`, `password`, sin `carne`) | `sql/03_migracion_sql_compartido.sql` |

   **No ejecutar los tres scripts**. La migración conserva datos previos. Si ya aplicaste una migración de Mentor, no necesitas aplicar las otras.

4. Copiar `.env.example` a `.env` y configurar DB_HOST, DB_NAME, DB_USER, DB_PASS, sin compartirlo ni subirlo a Git. El ZIP no incluye credenciales.
5. Si la base está vacía, crear el administrador desde terminal con PHP de XAMPP:

   ```powershell
   cd C:\xampp\htdocs\mentor
   C:\xampp\php\php.exe crear_admin.php ADMIN001 "Administrador" "UnaClaveSegura2026" "admin@ejemplo.edu"
   ```

   La contraseña se almacena con `password_hash`. No hay contraseñas de demostración predefinidas.
6. Abrir `http://localhost/mentor/` en el navegador.
7. Iniciar sesión como administrador y ejecutar este orden:
   - Crear carreras en **Carreras**.
   - Crear/editar materias en **Materias** y asociarlas a carreras.
   - Crear/editar alumnos en **Usuarios** y asignar carrera.
   - Crear/editar tutores en **Usuarios**.
   - En **Tutores**, marcar las materias que pueden impartir (de distintas carreras si procede).
   - Configurar los bloques en **Horarios**.
   - Un alumno crea una solicitud; el administrador asigna un profesor autorizado; tutor y alumno la encuentran en **Calendario**.

## Importante sobre la BD enviada

El SQL compartido tenía `correo` y `password`, mientras que el código anterior tenía `carne` y `contrasena`. Esta versión usa **carne**, **contrasena** y `correo` opcional: permite iniciar sesión con carné o correo. Para la base creada con el SQL del chat, el script 03 renombra `password` a `contrasena` (mantiene sus hashes) y crea `carne` con el correo como valor inicial. No es válido reemplazar directamente el esquema sin migración.

Los IDs de carreras históricas se dejan sin asignar (`NULL`) hasta que un administrador los complete; no se inventa una carrera de forma automática. Las materias sin carrera no aparecerán al alumno hasta que se actualicen.

## Archivos principales

- `api/calendario.php` API de agenda basada en sesión y rangos de fecha.
- `assets/calendario.js` vista y controles de navegación.
- `assets/mentor-extra.css` estilos de los módulos nuevos.
- `api/carreras.php`, `carreras.html` CRUD de carreras.
- `api/tutores_materias.php`, `tutores.html` relación tutor-materia.
- `api/alumno.php`, `api/solicitudes.php` nuevas validaciones y conflictos.
- `crear_admin.php` administrador inicial, solo ejecutable por CLI.

## Pruebas sugeridas para la defensa

1. Asignar un alumno de Sistemas y crear cuatro materias, dos de Sistemas y dos de Alimentos: el alumno solo ve las de Sistemas.
2. Configurar un tutor que imparta una materia de Sistemas y otra de Alimentos: el administrador puede elegirlo para ambas.
3. Crear una solicitud como alumno: aparece **amarilla (pendiente)** en su calendario, pero **no** en el del tutor.
4. Confirmar la solicitud desde el panel de administración: aparece **verde (confirmada)** en ambos calendarios.
5. Intentar solicitar otra tutoría para el mismo estudiante en un horario superpuesto: debe rechazarla.
6. Intentar asignar a un tutor otra tutoría en la misma fecha y rango horario: debe rechazarla.
7. Entrar como tutor: no debe ver tutorías pendientes ni las asignadas a otro profesor.
8. Probar los botones Mes, Semana, Agenda, hoy, anterior y siguiente en escritorio y móvil.

## Alcance de verificación

Se revisaron las dependencias internas del proyecto y la sintaxis PHP/JavaScript. **No se ejecutaron pruebas completas con MySQL real**, dado que este entorno carece del controlador `pdo_mysql` y de un servidor de base de datos conectado. Validar en XAMPP con una copia de la base antes de entregar. Los scripts de migración también deben verificarse en esa copia.

**Aviso académico:** el documento original del curso limita el uso de IA al 5% e indica que todos los integrantes deben poder explicar el código. Revisa la política del curso antes de incorporar este trabajo a una entrega evaluada.
