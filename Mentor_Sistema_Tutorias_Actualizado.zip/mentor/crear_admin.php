<?php
// SOLO CLI: php crear_admin.php CARNE "Nombre Admin" "clave-segura" [correo]
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo línea de comandos.'); }
if ($argc < 4) { fwrite(STDERR,"Uso: php crear_admin.php CARNE NOMBRE CLAVE [CORREO]\n"); exit(1); }
require_once __DIR__.'/conexion.php';
$carne=$argv[1];$nombre=$argv[2];$clave=$argv[3];$correo=$argv[4] ?? null;
if (strlen($clave)<8) { fwrite(STDERR,"La clave debe tener al menos 8 caracteres.\n");exit(1); }
try {
 $q=$pdo->prepare("INSERT INTO usuarios(carne,nombre,correo,contrasena,rol,activo) VALUES(?,?,?,?,'admin',1)");
 $q->execute([$carne,$nombre,$correo,password_hash($clave,PASSWORD_DEFAULT)]);
 echo "Administrador creado.\n";
} catch (PDOException $e) { fwrite(STDERR,"No fue posible crear el administrador; verifica duplicados.\n");exit(1); }
